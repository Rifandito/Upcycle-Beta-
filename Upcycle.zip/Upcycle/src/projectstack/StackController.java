package projectstack;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Stack;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class StackController implements Initializable {
    
    @FXML
    private Label label;
    
    @FXML
    private TextField tfPush, tfPop, tfStack;

    int a = 0;
    
    Stack<String> tumpukan = new Stack<>();

    XStream xstream = new XStream(new StaxDriver());
    
    @FXML
    private void handlePush(ActionEvent event) {
        tumpukan.push(tfPush.getText());
        tfPush.setText("");
        tfStack.setText(tumpukan.toString());

        saveDataToXML();
    }
    
    @FXML
    private void handlePop(ActionEvent event) {
        tfPop.setText(tumpukan.pop());
        tfStack.setText(tumpukan.toString());

        saveDataToXML();
    }
    
    @FXML
    private void clearAll(ActionEvent event) {
        tumpukan.clear();
        tfStack.setText(tumpukan.toString());

        saveDataToXML();
    }
    
    //method to save data to XML file
    private void saveDataToXML() {
        try {
            FileWriter writer = new FileWriter("D:/Rifandito Daniswara/Pendidikan Danis/Universitas Islam Indonesia/Kuliah/Semester 2/Fundamen Pengembangan Aplikasi/Setelah UTS/Pertemuan 21/Tugas/StrukturDataGUI/src/Data/dataStack.xml");
            xstream.toXML(tumpukan, writer);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //method to load data from XML file
    private void loadDataFromXML() {
        String path = "D:/Rifandito Daniswara/Pendidikan Danis/Universitas Islam Indonesia/Kuliah/Semester 2/Fundamen Pengembangan Aplikasi/Setelah UTS/Pertemuan 21/Tugas/StrukturDataGUI/src/Data/dataStack.xml";
        File file = new File(path);
        if (!file.exists()) {
            System.out.println("File does not exist");
        } else if (!file.canRead()) {
            System.out.println("File exists but cannot be read");
        } else {
            System.out.println("File exists and can be read");
        }

        try {
            
            FileReader reader = new FileReader(path);
            tumpukan = (Stack<String>) xstream.fromXML(reader);
            a = tumpukan.size();
            
            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //load Data
        System.out.println("Current directory: " + System.getProperty("user.dir"));
        loadDataFromXML();
    }    
    
}
