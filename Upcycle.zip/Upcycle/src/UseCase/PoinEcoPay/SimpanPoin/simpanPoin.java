package UseCase.PoinEcoPay.SimpanPoin;

public class simpanPoin {
    
}
