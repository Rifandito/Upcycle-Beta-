package UseCase.Barang.BarangProdusen;

import java.util.ArrayList;

import Pages.DataSaver;
import UseCase.Transaksi.Transaksi;

public class TestProduk {
    
    public static void main(String[] args) {
        
        DataSaver dataSaver = new DataSaver();

        String lokasiDataProduk = "src\\Data\\DataProduk\\dataProduk.xml";

        ArrayList<Produk> KumpulanProduk = new ArrayList<>();

        KumpulanProduk.add(new Produk("Bangku Biru Ecobrick", 40000, 100, "1"));
        KumpulanProduk.add(new Produk("Meja Merah Putih Ecobrick", 80000, 100, "2"));
        KumpulanProduk.add(new Produk("Meja Warna-warni Ecobrick", 30000, 100, "3"));
        KumpulanProduk.add(new Produk("Kursi Orange Ecobrick", 50000, 100, "4"));
        KumpulanProduk.add(new Produk("Bangku Kotak-kotak Ecobrick", 75000, 100, "5"));
        KumpulanProduk.add(new Produk("Pot Ecobrick", 35000, 100, "6"));
        KumpulanProduk.add(new Produk("Sofa Ecobrick", 150000, 100, "7"));
        KumpulanProduk.add(new Produk("Meja Dekorasi Ecobrick", 90000, 100, "8"));

        // Simpan data untuk setiap objek pengguna
        dataSaver.saveDataProduk(KumpulanProduk, lokasiDataProduk);

        // Load data 
        KumpulanProduk = dataSaver.loadDataProduk(lokasiDataProduk);

        if (!KumpulanProduk.isEmpty()) {
            KumpulanProduk.get(0).getProdukId();
        } else {
            System.out.println("Data Pengguna kosong atau tidak tersedia.");
        }
    }
}
