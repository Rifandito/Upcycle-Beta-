package UseCase.Barang.BarangProdusen.Hitung;

public class hitungProduk {
    
    Integer hasil;

    public hitungProduk(){
    }

    public Integer kurang(Integer saldo, Integer harga){
        return hasil = saldo - harga; 
    }

    public Integer tambah(Integer saldo, Integer penambah){
        return hasil = saldo + penambah; 
    }
}
