package UseCase.Barang.BarangPengepul.Simpan;

public class simpanSetoran {
    
}
