package UseCase.Transaksi;

public class Transaksi {
    
    private String NoTransaksi;
    private String TanggalTransaksi;
    private String JudulTransaksi;
    private String AlatTukar;
    private String Status;
    private String idTransaksi;

    public Transaksi(String NoTransaksi, String TanggalTransaksi, String JudulTransaksi, String AlatTukar, String Status, String idTransaksi){
        this.NoTransaksi = NoTransaksi;
        this.TanggalTransaksi = TanggalTransaksi;
        this.JudulTransaksi = JudulTransaksi;
        this.AlatTukar = AlatTukar;
        this.Status = Status;
        this.idTransaksi = idTransaksi;
    }

    public String getNoTransaksi(){
        return this.NoTransaksi;
    }

    public String getTanggalTransaksi(){
        return this.TanggalTransaksi;
    }

    public String getJudulTransaksi(){
        return this.JudulTransaksi;
    }

    public String getAlatTukar(){
        return this.AlatTukar;
    }

    public String getStatus(){
        return this.Status;
    }

    public String getidTransaksi(){
        return this.idTransaksi;
    }

    public void setNoTransaksi(String newNomer){
        this.NoTransaksi = newNomer;
    }

    public void getTanggalTransaksi(String newTanggal){
        this.TanggalTransaksi = newTanggal;
    } 

    public void setJudulTransaksi(String newJudul){
        this.JudulTransaksi = newJudul;
    }

    public void setAlatTukar(String newAlatTukar){
        this.AlatTukar = newAlatTukar;
    }

    public void setStatus(String newStatus){
        this.Status = newStatus;
    }

    public void setidTransaksi(String newidTransaksi){
        this.idTransaksi = newidTransaksi;
    }
}