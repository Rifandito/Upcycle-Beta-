package UseCase.Pengecek;

import java.util.ArrayList;

import Pages.DataSaver;

public class TestPengecek {
    
    public static void main(String[] args) {
   
        // data Pengguna
        // DataSaver dataSaver = new DataSaver();

        // String lokasiDataPengecekPengguna = "src\\Data\\DataPengecek\\dataPengecekPengguna.xml";

        // ArrayList<PengecekPengguna> KumpulanPengecekPengguna = new ArrayList<>();

        // KumpulanPengecekPengguna.add(new PengecekPengguna("0"));

        // // Simpan data untuk setiap objek pengguna
        // dataSaver.saveDataPengecekPengguna(KumpulanPengecekPengguna, lokasiDataPengecekPengguna);

        // // Load data 
        // KumpulanPengecekPengguna = dataSaver.loadDataPengecekPengguna(lokasiDataPengecekPengguna);

        // if (!KumpulanPengecekPengguna.isEmpty()) {
        //     KumpulanPengecekPengguna.get(0).getIdUser();
        // } else {
        //     System.out.println("Data Pengguna kosong atau tidak tersedia.");
        // }

        //data Produk
        // DataSaver dataSaver = new DataSaver();

        // String lokasiDataPengecekProduk = "src\\Data\\DataPengecek\\dataPengecekProduk.xml";

        // ArrayList<PengecekProduk> KumpulanPengecekProduk = new ArrayList<>();

        // KumpulanPengecekProduk.add(new PengecekProduk("0"));

        // // Simpan data untuk setiap objek pengguna
        // dataSaver.saveDataPengecekProduk(KumpulanPengecekProduk, lokasiDataPengecekProduk);

        // // Load data 
        // KumpulanPengecekProduk = dataSaver.loadDataPengecekProduk(lokasiDataPengecekProduk);

        // if (!KumpulanPengecekProduk.isEmpty()) {
        //     KumpulanPengecekProduk.get(0).getidProduk();
        // } else {
        //     System.out.println("Data Pengguna kosong atau tidak tersedia.");
        // }

        // data EcoPay
        DataSaver dataSaver = new DataSaver();

        String lokasiDataPengecekEcoPay = "src\\Data\\DataPengecek\\dataPengecekEcoPay.xml";

        ArrayList<PengecekEcoPay> KumpulanPengecekEcoPay = new ArrayList<>();

        KumpulanPengecekEcoPay.add(new PengecekEcoPay("0"));

        // Simpan data untuk setiap objek pengguna
        dataSaver.saveDataPengecekEcoPay(KumpulanPengecekEcoPay, lokasiDataPengecekEcoPay);

        // Load data 
        KumpulanPengecekEcoPay = dataSaver.loadDataPengecekEcoPay(lokasiDataPengecekEcoPay);

        if (!KumpulanPengecekEcoPay.isEmpty()) {
            KumpulanPengecekEcoPay.get(0).getalamatWallet();
        } else {
            System.out.println("Data Pengguna kosong atau tidak tersedia.");
        }

        //data Transaksi
        // DataSaver dataSaver = new DataSaver();

        // String lokasiDataPengecekTransaksi = "src\\Data\\DataPengecek\\dataPengecekTransaksi.xml";

        // ArrayList<PengecekTransaksi> KumpulanPengecekTransaksi = new ArrayList<>();

        // KumpulanPengecekTransaksi.add(new PengecekTransaksi("0"));

        // // Simpan data untuk setiap objek pengguna
        // dataSaver.saveDataPengecekTransaksi(KumpulanPengecekTransaksi, lokasiDataPengecekTransaksi);

        // // Load data 
        // KumpulanPengecekTransaksi = dataSaver.loadDataPengecekTransaksi(lokasiDataPengecekTransaksi);

        // if (!KumpulanPengecekTransaksi.isEmpty()) {
        //     KumpulanPengecekTransaksi.get(0).getidTransaksi();
        // } else {
        //     System.out.println("Data Pengguna kosong atau tidak tersedia.");
        // }
    }
}
