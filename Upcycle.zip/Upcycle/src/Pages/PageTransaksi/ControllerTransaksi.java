package Pages.PageTransaksi;

import java.net.URL;
import java.util.ResourceBundle;

import Pages.OpenScene;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class ControllerTransaksi implements Initializable{

    @FXML
    private BorderPane HalamanUtamaTransaksi, HalamanDetailTransaksi;

    @FXML
    private void keHalamanDetailTransaksi(ActionEvent event) {
        HalamanUtamaTransaksi.setVisible(false);
        HalamanDetailTransaksi.setVisible(true);
    }

    @FXML
    private void keHalamanTransaksi(ActionEvent event) {
        HalamanUtamaTransaksi.setVisible(true);
        HalamanDetailTransaksi.setVisible(false);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
}