package Pages.PageMateridanBerita;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class ControllerMateriBerita implements Initializable{
    
    @FXML

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
}