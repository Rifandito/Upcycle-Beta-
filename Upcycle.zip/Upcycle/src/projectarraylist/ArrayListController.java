/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectarraylist;

import Pages.DataSaver;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

public class ArrayListController implements Initializable {
    
    @FXML
    private TextField tfHasil, tfJumlah, tfIndex, tfValue;

    int a = 0;
    
    ArrayList<String> daftarData = new ArrayList<>();
    String fileName = "src\\Data\\dataArrayList.xml";  // Penambahan

    DataSaver dataSaver = new DataSaver();
    
    @FXML
    private void tambahData (ActionEvent event) {
        
        if (tfIndex.getText().equals("")){
            daftarData.add(tfValue.getText());
            a++;
        } else {
            daftarData.add(Integer.valueOf(tfIndex.getText()), tfValue.getText());
            a++;
        }
        tfValue.setText("");
        tfHasil.setText(daftarData.toString());
        String str = Integer.toString(a);
        tfJumlah.setText(str);

        saveData();
    }
    
    @FXML
    private void editData (ActionEvent event) {
        daftarData.set(Integer.valueOf(tfIndex.getText()), tfValue.getText());
        tfIndex.setText("");
        tfValue.setText("");
        tfHasil.setText(daftarData.get(0).toString());

        saveData();
    }   
    
    
    @FXML
    private void hapusData (ActionEvent event) {
        String inputIndex = tfIndex.getText();
        String inputValue = tfValue.getText();
        
        if(!inputIndex.equals("") && inputValue.equals("")) {
            // Hapus elemen berdasarkan index jika value kosong
            daftarData.remove(Integer.parseInt(inputIndex));
            a--;
        } else if (!inputIndex.equals("") && inputValue.equals(daftarData.get(Integer.parseInt(inputIndex)))) {
            // Hapus elemen berdasarkan index dan value (harus sesuai)
            daftarData.remove(Integer.parseInt(inputIndex));
            a--;
        }

        tfIndex.setText("");
        tfValue.setText("");
        tfHasil.setText(daftarData.toString());
        String str = Integer.toString(a);
        tfJumlah.setText(str);
        
        saveData();
    }
    
    @FXML
    private void clearAllData (ActionEvent event) {
        daftarData.clear();
        tfHasil.setText(daftarData.toString());
        a = 0;
        String str = Integer.toString(a);
        tfJumlah.setText(str);

        saveData();
    }

    //method to save data to XML file
    private void saveData() {
       // Panggil saveText dari DataSaver
        dataSaver.saveText(daftarData, fileName);
    }

    //method to load data from XML file
    private void loadData() {
        // Panggil loadText dari DataSaver
        daftarData = dataSaver.loadText(fileName, ArrayList.class);
        if(daftarData == null) {
            // Jika file tidak ditemukan atau tidak dapat dibaca, inisialisasi ArrayList baru
            daftarData = new ArrayList<>();
        } else {
            a = daftarData.size();
            tfHasil.setText(daftarData.toString());
            String str = Integer.toString(a);
            tfJumlah.setText(str);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //load Data
        System.out.println("Current directory: " + System.getProperty("user.dir"));
        loadData();
    }    
    
}
